﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace FindCapitalByState
{
    class Program
    {
        private const string Url = "http://services.groupkt.com/state/get/USA/all";

        static void Main(string[] args)
        {
            string input = string.Empty;
            do
            {
                Console.WriteLine("********************************************************************");
                Console.WriteLine("Input state name/abbreviation to search, type 'exit' to close application");
                Console.Write("Input : ");
                input = Console.ReadLine();
                FindCityByState(input);
            } while (!input.Equals("exit", StringComparison.OrdinalIgnoreCase));
        }

        private static void FindCityByState(string cityName)
        {
            string responseString = string.Empty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                responseString = reader.ReadToEnd();
            }
            if (!string.IsNullOrWhiteSpace(responseString))
            {
                var jObject = JObject.Parse(responseString);

                var statesList = JsonConvert.DeserializeObject<List<StateModel>>(jObject?["RestResponse"]?["result"]?.ToString());

                if (statesList.Any())
                {
                    var resultItem = statesList.Where(state => state.Name.Equals(cityName, StringComparison.OrdinalIgnoreCase) || state.Abbr.Equals(cityName, StringComparison.OrdinalIgnoreCase)).ToList();
                    if (resultItem.Any())
                    {
                        foreach (var stateItem in resultItem)
                        {
                            Console.WriteLine($"Largest City : {stateItem.LargestCity}, Capital : {stateItem.Capital}\n");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No result found : Invalid input\n");
                    }
                }
                else
                {
                    Console.WriteLine("No result found in API response\n");
                }
            }
            else
            {
                Console.WriteLine("No result returned from API\n");
            }
        }
    }
}
